package com.example.software

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
